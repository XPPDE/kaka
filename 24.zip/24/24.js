const playbtn = document.getElementById("playbtn");


playbtn.addEventListener("click", function() { 
    const name = document.getElementById('name').value;
    localStorage.setItem('username', name);     
    window.location.href = "gamescreen.html";
});