let startTime = Date.now();
let score = 0;
let isPaused = false;
const timerElement = document.getElementById('time');
const scorelbl = document.getElementById('score');
const btn = document.getElementById('gamebtn');
const pausemenu = document.getElementById('pausemenu');
const resutbtn = document.getElementById('resultbtn');
const nameP = document.getElementById('name');
const name = localStorage.getItem('username');

nameP.textContent = name;

resutbtn.addEventListener("click", function() {  
    window.location.href = "resultscreen.html";
});

document.addEventListener('keydown', function(event) {
    if (event.code === 'Space') {
        if (isPaused == false) {
            isPaused = true;
            pausemenu.style.display = 'flex';
        }
        else {
            isPaused = false;
            pausemenu.style.display = 'none';
        }
    }
});

btn.addEventListener('mousedown', function(event) {
    if (event.button == 0)
        score += 5;
    else if (event.button == 2)
        score += 10;
    scorelbl.textContent = `Счет: ${score}`;
});

function updateTimer() {
    if (isPaused == false) {
        let now = Date.now();
        let diff = Math.floor((now - startTime) / 1000);
        
        let minutes = Math.floor(diff / 60);
        let seconds = diff % 60;
        
        let mm = String(minutes).padStart(2, '0');
        let ss = String(seconds).padStart(2, '0');
        
        timerElement.textContent = `Время: ${mm}:${ss}`;
    }
}

setInterval(updateTimer, 1000);