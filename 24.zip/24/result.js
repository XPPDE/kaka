// const list = document.getElementById('results');
// const newItem = document.createElement('li');
// let data;

// list.appendChild(newItem);
