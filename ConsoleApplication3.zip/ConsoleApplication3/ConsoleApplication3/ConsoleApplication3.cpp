﻿#include <iostream>

int main()
{
    setlocale(LC_ALL, "Rus");
    std::cout << "Hello World!\n";
    double mas[10], sum = 0;
    double min = 0;
    double max = 0;
    for (size_t i = 0; i < 10; i++)
    {
        std::cin >> mas[i];
    }


    min = mas[0];
    max = mas[0];


    for (size_t i = 0; i < 10; i++)
    {

        std::cout << mas[i] << " " << i << std::endl;
    }

    for (size_t i = 0; i < 10; i++)
    {
        sum = sum + mas[i];
    }
    std::cout << std::endl << "Сумма чисел массива: " << sum << std::endl;

    for (size_t i = 0; i < 10; i++)
    {

        if (mas[i] > max)
            max = mas[i];

        if (mas[i] < min)
            min = mas[i];


    }
    std::cout << std::endl << "Максимальное значение: " << min << " Минимальное значение: " << max << std::endl;

}
