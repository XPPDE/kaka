﻿using System.Diagnostics;

double Power(double x, int n)
{
    if (n == 0)
    {
        Debug.Assert(false, "Показатель степени равен нулю");
        return 1.0;
    }
    if (x == 0)
    {
        Debug.Assert(false, "Значение x равно нулю");
        return 0.0;
    }

    if (n < 0)
    {
        return 1.0 / Power(x, -n);
    }
    else
    {
        return x * Power(x, n - 1);
    }
}

double FastPower(double x, int n)
{
    if (n < 0)
    {
        return -1;
    }
    if (n == 0)
        return 1.0;
    if (n == 1)
        return x;

    if (n % 2 == 0)
    {
        double halfPower = FastPower(x, n / 2);
        Debug.Assert(false, "Промежуточное значение");
        return halfPower * halfPower;
    }
    else 
    {
        double halfPower = FastPower(x, (n - 1) / 2);
        Debug.Assert(false, "Промежуточное значение");
        return x * halfPower * halfPower;
    }
}

Console.WriteLine(Power(3, 2));
Console.WriteLine(Power(3, -4));
Console.WriteLine(Power(-3, 2));
Console.WriteLine(Power(-4, -4));

Console.WriteLine(FastPower(-2, -2));
Console.WriteLine(FastPower(2, 15));