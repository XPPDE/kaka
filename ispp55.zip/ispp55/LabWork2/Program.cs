﻿using System.Diagnostics;

int[] array = { 7, 0, -4, 3, 1, -2, 5 };
int[] increasingArray = { 3, 8, 12, 13, 16, 20, 21 };
int[] decreasingArray = { 32, 21, 6, 2, -4, -38, -40 };
int[] firstElArray = { 2, 3, 4, 5, 1 };
int[] lastElArray = { 5, 1, 2, 3, 4 };

void SelectionSort(int[] array)
{
    int n = array.Length;
    for (int i = 0; i < n - 1; i++)
    {
        int minIndex = i;
        Debug.Assert(false, $"Минимальный индекс: {minIndex}");
        for (int j = i + 1; j < n; j++)
        {
            if (array[j] < array[minIndex])
            {
                minIndex = j;
            }
        }
        if (minIndex != i)
        {
            int temp = array[i];
            array[i] = array[minIndex];
            array[minIndex] = temp;
        }
        Console.WriteLine(string.Join("\t", array));
    }
    Console.WriteLine("\n");
}

void BubbleSort(int[] array)
{
    int n = array.Length;
    Debug.Assert(false, $"Длина массива: {array.Length}");
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (array[j] > array[j + 1])
            {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
                Debug.Assert(false, $"Элемент с индексом {array[j]} поменялся с {array[j + 1]}");
            }
        }
    }
}

void InsertionSort(int[] array)
{
    int n = array.Length;
    Debug.Assert(false, $"Длина массива: {array.Length}");
    for (int i = 1; i < n; i++)
    {
        int temp = array[i];

        int j = i - 1;

        while (j >= 0 && array[j] > temp)
        {
            array[j + 1] = array[j];
            j--;
        }
        array[j + 1] = temp;
    }
}

SelectionSort(array);
SelectionSort(increasingArray);
SelectionSort(decreasingArray);
SelectionSort(firstElArray);
SelectionSort(lastElArray);

//BubbleSort(array);
//BubbleSort(increasingArray);
//BubbleSort(decreasingArray);
//BubbleSort(firstElArray);
//BubbleSort(lastElArray);

//InsertionSort(array);
//InsertionSort(increasingArray);
//InsertionSort(decreasingArray);
//InsertionSort(firstElArray);
//InsertionSort(lastElArray);
