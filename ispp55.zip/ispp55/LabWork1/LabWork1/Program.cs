﻿using System.Diagnostics;

int[] array = [1, 2, 3, 4, 4, 5];

Debug.Assert(LinearSearch(array, 1) == 0, "Первый элемент не найден");
Debug.Assert(LinearSearch(array,10) == -1, "Числа 10 нет в массиве");


//Console.WriteLine(BinarySearch(array, 1));
//Debug.Assert(BinarySearch(array, 1) == 0, "элемент не найден");
//Debug.Assert(BinarySearch(array, 2) == 1, "элемент не найден");
//Debug.Assert(BinarySearch(array, 3) == 2, "элемент не найден");
//Debug.Assert(BinarySearch(array, 4) == 3, "элемент не найден");

int LinearSearch(int[] array, int target)
{
    for (int i = 0; i < array.Length; i++)
    {
        Debug.Assert(i != 0, "Поиск начался с 0");
        if (target == array[i])
            Debug.Assert(false, $"Число: {target} с индексом: {i}");
            return i;
    }
    return -1;
}

int BinarySearch(int[] array, int n)
{
    int index = Array.BinarySearch(array, n);
    if (index < 0) 
        return -1; 
    else 
        return index;
}
