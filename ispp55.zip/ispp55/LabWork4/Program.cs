﻿int[] denominations = { 10, 5, 2, 1 };

void PrintChange(int[] denomination, int sum) { 
    Console.WriteLine($"Сдача для суммы {sum}");
    int amount = sum;

    for (int i = 0; i < denomination.Length; i++)
    {
        if (amount <= 0) break;

        if ((amount / denomination[i]) > 0)
        {
            Console.WriteLine($"{denomination[i]}: {(amount / denomination[i])}");
            amount %= denomination[i];
        }
    }
    if (amount > 0)
        Console.WriteLine($"Не удалось выдать остаток {amount} доступными монетами.");
}

PrintChange(denominations, 12);
PrintChange(denominations, 3);
PrintChange(denominations, 15);
PrintChange(denominations, 7);
PrintChange(denominations, 184);
PrintChange(denominations, 93);

